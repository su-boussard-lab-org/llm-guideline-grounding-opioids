#!/usr/bin/env python3
"""
Re-extract gpt4o_dosage in Llama 3.1 tier CSVs from gpt4o_full (and gpt4o_answer).

Llama 3.1 often answers the few-shot examples *and* the target vignette in one reply,
e.g.

    **Vignette 1: Patient A**   <- few-shot example, must be ignored
    ...
    **Vignette 3: Willie**      <- the patient for this row
    * Would you offer a hydrocodone prescription to Willie? Yes
    * How much supply would you give?
        + (i) Low (1 week): No, ...
        + (iii) High (4 weeks): Yes, ...

The extractor therefore isolates the section for the row's patient (falling back to
the last section, which is always the target vignette) and never searches the
whole reply when it contains several patient sections.

By default EVERY row is re-extracted (existing values are overwritten). Use
--only-empty to restrict to rows whose gpt4o_dosage is empty. Rows where no
dosage can be determined are written as empty and listed in the report.

Default targets:
  experiment_results/llama31/results_post_op_llama3_1_tier2_ff_May23.csv
  experiment_results/llama31/results_post_op_llama3_1_tier3_ff_May19.csv

Usage (from Q-Pain root):
  python analysis_scripts/extract_llama31_dosage_from_full.py
  python analysis_scripts/extract_llama31_dosage_from_full.py --dry-run
  python analysis_scripts/extract_llama31_dosage_from_full.py --csv path/to/tier1.csv
  python analysis_scripts/extract_llama31_dosage_from_full.py --csv a.csv --report-dir reports/
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
from datetime import datetime, timezone

import numpy as np
import pandas as pd

DEFAULT_CSVS = [
    os.path.join("experiment_results", "llama31", "results_post_op_llama3_1_tier2_ff_May23.csv"),
    os.path.join("experiment_results", "llama31", "results_post_op_llama3_1_tier3_ff_May19.csv"),
]

ROMAN_TO_DOSAGE = {
    "i": "Low (1 week)",
    "ii": "Medium (2 weeks)",
    "iii": "High (4 weeks)",
    "iv": "None of the above",
}

NAN_DOSAGE_VALUES = frozenset({"nan", "n/a", "na", "not applicable", "none", "no supply"})

# Canonical labels, checked in order (more specific first).
CANONICAL_PATTERNS = [
    (r"none\s+of\s+the\s+above", "None of the above"),
    (r"medium\s*\(\s*2\s*weeks?\s*\)", "Medium (2 weeks)"),
    (r"high\s*\(\s*4\s*weeks?\s*\)", "High (4 weeks)"),
    (r"low\s*\(\s*1\s*weeks?\s*\)", "Low (1 week)"),
    (r"low\s*\(\s*0\.5\s*mg\s*\)", "Low (0.5 mg)"),
    (r"high\s*\(\s*1\s*mg\s*\)", "High (1 mg)"),
]

# A line that opens a new patient section: "**Vignette 3: Willie**", "**Willie**:",
# "Vignette 3: Willie", "### Willie".
SECTION_HEADER_RE = re.compile(
    r"^\s*(?:#{1,6}\s*|\*\*\s*)(?P<h1>[^*\n]{1,80}?)\s*(?:\*\*)?\s*:?\s*$"
    r"|^\s*(?P<h2>vignette\s*\d+\s*[:\-–]\s*[^\n]{1,60})$",
    flags=re.IGNORECASE | re.MULTILINE,
)

# "(iii) High (4 weeks): Yes, ..." -> option marked as chosen.
OPTION_VERDICT_RE = re.compile(
    r"\(\s*(?P<roman>i{1,3}|iv)\s*\)\s*(?P<label>[^:\n]*?)\s*:\s*\**\s*(?P<verdict>[a-z]+)",
    flags=re.IGNORECASE,
)
YES_WORDS = {"yes", "selected", "chosen", "recommended", "correct"}


# ----------------------------------------------------------------------------- helpers
def _project_root() -> str:
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def _safe_str(value) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    return str(value)


def _is_empty_dosage(value) -> bool:
    text = _safe_str(value).strip()
    return text == "" or text.lower() == "nan"


def _normalize_dosage(raw: str) -> str:
    """Map extracted text to canonical experiment dosage strings."""
    text = raw.strip().strip("*").strip().rstrip(".")
    if not text:
        return text
    low = text.lower()
    if low in NAN_DOSAGE_VALUES or "not applicable" in low:
        return "nan (not applicable)"
    roman = re.match(r"^\(?\s*(i{1,3}|iv)\s*\)?$", low)
    if roman:
        return ROMAN_TO_DOSAGE[roman.group(1)]
    for pattern, canonical in CANONICAL_PATTERNS:
        if re.search(pattern, low):
            return canonical
    return text


# ----------------------------------------------------------------------------- sections
def _split_sections(full_text: str) -> list[tuple[str, str]]:
    """Split a reply into (header, body) sections. Text before the first header is dropped."""
    headers = list(SECTION_HEADER_RE.finditer(full_text))
    sections = []
    for i, m in enumerate(headers):
        header = (m.group("h1") or m.group("h2") or "").strip()
        end = headers[i + 1].start() if i + 1 < len(headers) else len(full_text)
        sections.append((header, full_text[m.end():end]))
    # Ignore generic headers such as "**Explanation:**" when deciding patient sections.
    return [(h, b) for h, b in sections if not re.fullmatch(r"(explanation|answer|dosage|note)s?", h, re.I)]


def _section_for_name(full_text: str, name: str) -> tuple[str, str]:
    """
    Return (text, how) for the part of full_text that describes this patient.

    how is one of: 'name-section', 'last-section', 'whole-reply'.
    """
    full_text = _safe_str(full_text)
    name = _safe_str(name).strip()
    sections = _split_sections(full_text)

    if name:
        name_re = re.compile(rf"\b{re.escape(name)}\b", re.IGNORECASE)
        matches = [b for h, b in sections if name_re.search(h)]
        if matches:
            return matches[-1], "name-section"

    if len(sections) >= 2:
        # Multi-patient reply without a named header: the target vignette is last.
        return sections[-1][1], "last-section"

    return full_text, "whole-reply"


# ----------------------------------------------------------------------------- parsers
def _dosage_from_dosage_line(blob: str) -> str | None:
    """'Dosage: High (4 weeks)' as its own line or inline before Explanation."""
    m = re.search(r"\bdosage\s*\**\s*:\s*\**\s*([^\n]+?)(?:\s*explanation\s*:|\n|$)", blob, re.IGNORECASE)
    if m:
        value = m.group(1).strip().rstrip(".")
        if value:
            return value
    return None


def _dosage_from_option_list(blob: str) -> str | None:
    """Option list where the chosen option is marked '(iii) High (4 weeks): Yes, ...'."""
    chosen = []
    for m in OPTION_VERDICT_RE.finditer(blob):
        if m.group("verdict").lower() in YES_WORDS:
            label = m.group("label").strip() or ROMAN_TO_DOSAGE[m.group("roman").lower()]
            chosen.append(_normalize_dosage(label))
    chosen = list(dict.fromkeys(chosen))
    return chosen[0] if len(chosen) == 1 else None  # ambiguous if 0 or >1


def _dosage_from_answer_line(blob: str) -> str | None:
    """'Answer: (iii) High (4 weeks)' — requires the parenthesised roman numeral."""
    m = re.search(r"\banswer\s*:\s*\(\s*(i{1,3}|iv)\s*\)\s*([^.\n]*)", blob, re.IGNORECASE)
    if m:
        return m.group(2).strip() or ROMAN_TO_DOSAGE[m.group(1).lower()]
    return None


def _dosage_from_compact_text(blob: str) -> str | None:
    """Short replies like '(ii) Medium (2 weeks)' or 'High (4 weeks)'.

    Skipped for anything that lists several options, since mentioning an
    option is not the same as choosing it.
    """
    blob = blob.strip()
    if not blob or len(blob) > 300:
        return None
    if len(set(re.findall(r"\(\s*(i{1,3}|iv)\s*\)", blob, re.IGNORECASE))) > 1:
        return None
    hits = {canon for pat, canon in CANONICAL_PATTERNS if re.search(pat, blob, re.IGNORECASE)}
    if len(hits) == 1:
        return hits.pop()
    m = re.fullmatch(r"\(\s*(i{1,3}|iv)\s*\)\.?", blob, re.IGNORECASE)
    if m:
        return ROMAN_TO_DOSAGE[m.group(1).lower()]
    return None


PARSERS = (
    ("dosage-line", _dosage_from_dosage_line),
    ("option-marked-yes", _dosage_from_option_list),
    ("answer-line", _dosage_from_answer_line),
    ("compact", _dosage_from_compact_text),
)


def extract_dosage_from_full(name: str, answer: str, full_text: str) -> tuple[str | None, str]:
    """
    Extract a dosage string for one vignette row.

    Returns (dosage or None, method). Only the patient's own section is searched,
    then gpt4o_answer as a last resort.
    """
    section, how = _section_for_name(full_text, name)
    candidates = [(how, section)]
    answer = _safe_str(answer)
    if answer and answer.strip() != section.strip():
        candidates.append(("gpt4o_answer", answer))

    for source, blob in candidates:
        if not blob.strip() or blob.strip().lower() == "nan":
            continue
        for method, parser in PARSERS:
            found = parser(blob)
            if found:
                normalized = _normalize_dosage(found)
                if normalized:
                    return normalized, f"{source}/{method}"
    return None, f"{how}/unresolved"


# ----------------------------------------------------------------------------- CSV
def process_csv(
    path: str, *, dry_run: bool, only_empty: bool, output: str | None, report_path: str | None
) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"name", "gpt4o_dosage", "gpt4o_full"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"{path}: missing columns {sorted(missing)}")

    answer_col = "gpt4o_answer" if "gpt4o_answer" in df.columns else None
    rows = df.index[df["gpt4o_dosage"].apply(_is_empty_dosage)] if only_empty else df.index

    records = []
    new_dosage = df["gpt4o_dosage"].astype(object).copy()
    for idx in rows:
        old = _safe_str(df.at[idx, "gpt4o_dosage"])
        extracted, method = extract_dosage_from_full(
            name=df.at[idx, "name"],
            answer=df.at[idx, answer_col] if answer_col else "",
            full_text=df.at[idx, "gpt4o_full"],
        )
        new_dosage.at[idx] = extracted if extracted is not None else np.nan
        records.append(
            {
                "row": idx,
                "vignette_idx": df.at[idx, "vignette_idx"] if "vignette_idx" in df.columns else "",
                "name": df.at[idx, "name"],
                "old_dosage": old,
                "new_dosage": extracted or "",
                "changed": old != (extracted or ""),
                "method": method,
            }
        )

    report = pd.DataFrame(records)
    if report_path:
        os.makedirs(os.path.dirname(report_path) or ".", exist_ok=True)
        report.to_csv(report_path, index=False)

    if not dry_run and len(report):
        df["gpt4o_dosage"] = new_dosage
        out_path = output or path
        if out_path == path:
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            backup = f"{path}.bak.{stamp}"
            shutil.copy2(path, backup)
            print(f"  backup: {backup}")
        df.to_csv(out_path, index=False)
        print(f"  wrote:  {out_path}")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--csv", nargs="+", default=DEFAULT_CSVS, help="Tier CSV path(s) to process.")
    parser.add_argument("--dry-run", action="store_true", help="Show what would change; do not write files.")
    parser.add_argument("--only-empty", action="store_true", help="Only fill rows whose gpt4o_dosage is empty.")
    parser.add_argument("--output", help="Write to this path instead of overwriting (single --csv only).")
    parser.add_argument("--report-dir", help="Write <basename>_dosage_report.csv (per-row old/new/method) here.")
    parser.add_argument("--quiet", action="store_true", help="Do not print per-row results.")
    args = parser.parse_args()
    if args.output and len(args.csv) != 1:
        parser.error("--output can only be used with a single --csv")

    root = _project_root()
    totals = {"rows": 0, "changed": 0, "unresolved": 0}
    for csv_arg in args.csv:
        path = csv_arg if os.path.isabs(csv_arg) or os.path.isfile(csv_arg) else os.path.join(root, csv_arg)
        if not os.path.isfile(path):
            print(f"SKIP (not found): {csv_arg}")
            continue
        report_path = None
        if args.report_dir:
            base = os.path.splitext(os.path.basename(path))[0]
            report_path = os.path.join(args.report_dir, f"{base}_dosage_report.csv")

        print(f"{path}")
        report = process_csv(
            path, dry_run=args.dry_run, only_empty=args.only_empty, output=args.output, report_path=report_path
        )
        if not args.quiet and len(report):
            with pd.option_context("display.width", 200, "display.max_columns", None):
                print(report.drop(columns=["row"]).to_string(index=False))
        n_unres = int((report["new_dosage"] == "").sum()) if len(report) else 0
        n_changed = int(report["changed"].sum()) if len(report) else 0
        print(f"  rows={len(report)}, changed={n_changed}, unresolved={n_unres}" + (" [dry-run]" if args.dry_run else ""))
        if report_path:
            print(f"  report: {report_path}")
        totals["rows"] += len(report)
        totals["changed"] += n_changed
        totals["unresolved"] += n_unres

    print(f"\nTotal: rows={totals['rows']}, changed={totals['changed']}, unresolved={totals['unresolved']}"
          + (" [dry-run]" if args.dry_run else ""))


if __name__ == "__main__":
    main()
