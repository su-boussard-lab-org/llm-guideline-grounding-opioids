#!/usr/bin/env python3
"""
Re-derive *_dosage from the model's own reply (*_full, then *_answer) for EVERY row,
and overwrite cells where the stored value disagrees.

Why: an earlier parser picked up words like "high" from the explanation
("A high/4-week supply would be excessive") instead of the "Dosage: Low (1 week)" line.

Priority per row:
  1. An explicit "Dosage: ..." line (markdown/bullets tolerated), in *_full then *_answer.
  2. The top of the reply in compact form: "Yes. Low (1 week) supply." / "Yes\\nHigh (1 week)".
  The explanation text is never used.

Output labels keep the style already used in each file:
  bare  -> Low / Medium / High / None of the above   (e.g. tier 2 files)
  long  -> Low (1 week) / Medium (2 weeks) / High (4 weeks) / Low (0.5 mg) / High (1 mg)

Usage:
  python analysis_scripts/fix_experiment_dosage_from_full.py --dirs experiment_results/gpt54 --dry-run
  python analysis_scripts/fix_experiment_dosage_from_full.py --files path/to/file.csv

Writes in place with a timestamped .bak copy, plus a <name>.dosage_changes.csv report
listing every changed row.
"""

from __future__ import annotations

import argparse
import glob
import os
import re
import shutil
from collections import Counter
from datetime import datetime, timezone

import pandas as pd

# Option word at the start of a value: "Low", "**High**", "Medium (2 weeks)", "None of the above".
_WORD_RE = re.compile(r"^[\W_]*(none\s+of\s+the\s+above|low|medium|high)\b", re.I)
# Standalone "Dosage: ..." line, e.g. "**Dosage:** Low (1 week)", "- Dosage - High".
_DOSAGE_LINE_RE = re.compile(
    r"^[\s>*_#`\-•\d.)]*dosage[*_`\s]*[:\-–—][*_`\s]*(?P<val>.+?)\s*$", re.I
)
_YES_NO_RE = re.compile(r"^[\W_]*(yes|no)\b[\s.,:;!\-–—]*", re.I)
_WEEKS_RE = re.compile(r"\(\s*(\d+)\s*weeks?\s*\)", re.I)
_MG_RE = re.compile(r"\(\s*([\d.]+)\s*mg\s*\)", re.I)

_DEFAULT_LONG = {
    "Low": "Low (1 week)",
    "Medium": "Medium (2 weeks)",
    "High": "High (4 weeks)",
    "None of the above": "None of the above",
}
_EXPECTED_WEEKS = {"Low": 1, "Medium": 2, "High": 4}


def _s(x) -> str:
    return "" if x is None or (isinstance(x, float) and pd.isna(x)) else str(x)


def _lines(text: str) -> list[str]:
    text = text.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\r\n", "\n")
    return [l.strip() for l in text.splitlines() if l.strip()]


def _word(value: str) -> str | None:
    m = _WORD_RE.match(value)
    if not m:
        return None
    w = m.group(1).lower()
    return "None of the above" if w.startswith("none") else w.capitalize()


def extract(full, answer) -> tuple[str | None, str, str]:
    """Return (option_word, source, matched_text). option_word is Low/Medium/High/None of the above."""
    texts = [_s(full), _s(answer)]
    for t in texts:  # 1) explicit Dosage: line
        for line in _lines(t):
            m = _DOSAGE_LINE_RE.match(line)
            if m:
                w = _word(m.group("val"))
                if w:
                    return w, "dosage_line", line
    for t in texts:  # 2) compact form in the first two lines only
        for line in _lines(t)[:2]:
            w = _word(_YES_NO_RE.sub("", line, count=1))
            if w:
                return w, "top_line", line
    return None, "unparsed", ""


def _conflict(word: str, matched: str) -> bool:
    """True if the label and the duration disagree, e.g. 'High (1 week)'."""
    m = _WEEKS_RE.search(matched)
    return bool(m and word in _EXPECTED_WEEKS and int(m.group(1)) != _EXPECTED_WEEKS[word])


def _style(series: pd.Series) -> tuple[str, dict[str, str]]:
    """Detect bare vs long labels in the existing column, and the long form used per option."""
    vals = [v.strip() for v in series.dropna().astype(str) if v.strip() and v.strip().lower() != "nan"]
    if not vals:
        return "long", dict(_DEFAULT_LONG)
    long_count = sum("(" in v for v in vals)
    style = "long" if long_count > len(vals) / 2 else "bare"
    long_map = dict(_DEFAULT_LONG)
    per_word: dict[str, Counter] = {}
    for v in vals:
        w = _word(v)
        if w and ("(" in v):
            m = _WEEKS_RE.search(v) or _MG_RE.search(v)
            if m:
                unit = "mg" if "mg" in m.group(0).lower() else ("week" if m.group(1) == "1" else "weeks")
                per_word.setdefault(w, Counter())[f"{w} ({m.group(1)} {unit})"] += 1
    for w, c in per_word.items():
        long_map[w] = c.most_common(1)[0][0]
    return style, long_map


def _find_cols(df: pd.DataFrame) -> tuple[str, str | None, str | None] | None:
    dosage_cols = [c for c in df.columns if str(c).lower().endswith("_dosage")]
    if not dosage_cols:
        return None
    dc = next((p for p in ("gpt54_dosage", "gpt4o_dosage") if p in dosage_cols), dosage_cols[0])
    prefix = dc[: -len("_dosage")]
    fc = f"{prefix}_full" if f"{prefix}_full" in df.columns else None
    ac = f"{prefix}_answer" if f"{prefix}_answer" in df.columns else None
    if not fc and not ac:
        return None
    return dc, fc, ac


def fix_csv(path: str, *, dry_run: bool) -> dict:
    df = pd.read_csv(path)
    cols = _find_cols(df)
    if not cols:
        return {"skipped": "no *_dosage with matching *_full / *_answer"}
    dc, fc, ac = cols
    style, long_map = _style(df[dc])

    new_col = df[dc].astype(object).copy()
    report = []
    unparsed = conflicts = 0
    for idx in df.index:
        word, source, matched = extract(df.at[idx, fc] if fc else "", df.at[idx, ac] if ac else "")
        if word is None:
            unparsed += 1
            continue  # leave the stored value alone; we couldn't read the reply
        is_conflict = _conflict(word, matched)
        conflicts += is_conflict
        label = word if style == "bare" else long_map.get(word, word)
        old = _s(df.at[idx, dc]).strip()
        if old != label:
            new_col.at[idx] = label
            report.append({"row": idx, "old_dosage": old, "new_dosage": label, "source": source,
                           "label_duration_conflict": is_conflict, "matched_text": matched})

    if report and not dry_run:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        shutil.copy2(path, f"{path}.bak.{ts}")
        df[dc] = new_col
        df.to_csv(path, index=False)
        pd.DataFrame(report).to_csv(os.path.splitext(path)[0] + ".dosage_changes.csv", index=False)

    transitions = Counter(f"{r['old_dosage'] or '<empty>'} -> {r['new_dosage']}" for r in report)
    return {"column": dc, "style": style, "rows": len(df), "changed": len(report),
            "unparsed": unparsed, "conflicts": conflicts, "transitions": dict(transitions)}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dirs", nargs="*", default=[], help="Directories of CSVs to fix.")
    ap.add_argument("--files", nargs="*", default=[], help="Individual CSV files to fix.")
    ap.add_argument("--glob", default="*.csv", help="Filename glob within each dir (default: *.csv).")
    ap.add_argument("--dry-run", action="store_true", help="Report changes without writing files.")
    args = ap.parse_args()

    paths = list(args.files)
    for d in args.dirs:
        if not os.path.isdir(d):
            print(f"SKIP (not a dir): {d}")
            continue
        paths += sorted(glob.glob(os.path.join(d, args.glob)))
    paths = [p for p in paths if p.endswith(".csv") and not p.endswith(".dosage_changes.csv")]
    if not paths:
        ap.error("no CSV files given (use --dirs and/or --files)")

    total = 0
    for p in paths:
        r = fix_csv(p, dry_run=args.dry_run)
        if "skipped" in r:
            print(f"{p}: SKIP ({r['skipped']})")
            continue
        total += r["changed"]
        tag = " [dry-run]" if args.dry_run else ""
        print(f"{p}: {r['column']} ({r['style']} labels) rows={r['rows']} changed={r['changed']} "
              f"unparsed={r['unparsed']} label/duration conflicts={r['conflicts']}{tag}")
        for t, n in sorted(r["transitions"].items(), key=lambda kv: -kv[1]):
            print(f"    {t}: {n}")
    print(f"\nTotal rows changed: {total}" + (" [dry-run]" if args.dry_run else ""))


if __name__ == "__main__":
    main()
